# [Name]Mariah Moore
## [Assignment #]Assignment 6
## [Submission date: MM/DD/YY] 10/27/2022
## Worked with/sources 
* https://stackoverflow.com/questions/32257736/app-use-express-serve-multiple-html
## Project Quirks/ Things that don't work
* 
### [URL]http://localhost:8080/

# score [50/60]
## General requirements  
* [5/5] code updated on repo and hosted page  
## Root route
* [5/5] Display a default page that allows navigation to both create and login
## Create
* [4/4] Allow the user to input a username and password
* [4/4] Return back to the client if the account cannot be created 
* [4/4] Return back to the client if creation successful 
* [4/4] Usernames and passwords stored in DB
## Login
* [4/4] A place for the client to supply username and password
* [4/4] Display if login successful 
* [4/4] Display if login unsuccessfull 
## Git requirements
* [4/4] server file
* [4/4] Client files in appropriate directory
* [0/4] Git ignore with node modules idnored
## README.md requirements
[2/2] Your name
[2/2] The assignment number
[2/2] Submission date
[2/2] Sources/collaborators 
[2/2] program issues/quirks

Your server crashes after every interaction -6
https://stackoverflow.com/questions/7042340/error-cant-set-headers-after-they-are-sent-to-the-client
